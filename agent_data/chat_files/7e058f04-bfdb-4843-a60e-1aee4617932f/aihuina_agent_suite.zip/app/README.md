# ChatAihuina

Локальный ИИ-агент для работы с файлами и кодом. Модель может читать, создавать и
редактировать файлы в рабочей папке, выполнять команды оболочки и отправлять файлы.
Есть веб-интерфейс (чат с потоковым ответом по WebSocket) и консольный режим.

Поддерживаемые провайдеры: **LM Studio**, **Ollama**, **OpenAI**, **xAI (Grok)**
и любой OpenAI-совместимый сервер.

## Возможности

- Несколько чатов с сохранением истории на диск
- Потоковый вывод ответа и блок рассуждений (режим Think)
- Инструменты: чтение, запись, точечное редактирование, перемещение и список файлов,
  выполнение команд, отправка файлов
- Выбор рабочей папки для каждого чата
- Загрузка вложений в чат
- Переключение провайдера и модели прямо из интерфейса

## Структура проекта

```
chatai/
├── install.sh / install.bat # установка и запуск одной командой
├── pyproject.toml          # пакет и команда chatai
├── run.py                  # запуск без установки
├── requirements.txt
├── .env.example            # пример переменных окружения
├── README.md
├── tests/
│   └── test_smoke.py       # базовые тесты
└── aihuina/                # пакет приложения
    ├── __init__.py
    ├── __main__.py         # запуск через python -m aihuina
    ├── main.py             # баннер, выбор режима веб/CLI
    ├── config.py           # провайдеры, пути, лимиты, режимы усилия
    ├── utils.py            # загрузка/сохранение JSON, проверка путей
    ├── providers.py        # ключи, URL и список моделей провайдеров
    ├── settings.py         # сохранение настроек провайдера и рабочей папки
    ├── workspace.py        # рабочие папки чатов и синхронизация
    ├── file_tools.py       # инструменты: файлы и команды оболочки
    ├── edit.py             # движок точечного редактирования файлов
    ├── actions.py          # выполнение действий, которые запросила модель
    ├── prompts.py          # системные промпты
    ├── llm.py              # потоковый вызов LLM-API
    ├── parsing.py          # разбор тегов ответа модели
    ├── agent.py            # цикл диалога агента
    ├── chat.py             # состояние чатов и их хранение
    ├── websocket.py        # минимальный WebSocket поверх http.server
    ├── server.py           # HTTP-обработчик (статика, API, WebSocket)
    ├── webpage.py          # загрузка HTML-интерфейса
    ├── cli.py              # консольный режим
    └── web/
        └── index.html      # веб-интерфейс
```

Основные зависимости между слоями: `config` → `providers`/`settings` → инструменты
(`file_tools`, `edit`, `actions`) → `llm`/`parsing` → `agent` → `chat` → `server`/`cli` → `main`.

## Быстрый старт

Самый простой способ — скрипт установки. Он создаёт виртуальное окружение,
ставит зависимости, создаёт `.env` и запускает приложение.

**Windows:** дважды щёлкните `install.bat` или выполните в терминале:

```bat
install.bat
```

**Linux / macOS:**

```bash
./install.sh
```

Консольный режим: `install.bat --cli` или `./install.sh --cli`.

После установки веб-интерфейс откроется по адресу http://127.0.0.1:8080.

## Установка вручную

Требуется Python 3.9+.

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -e .
chatai                             # веб-интерфейс
chatai --cli                       # консольный режим
```

Без установки пакета: `pip install -r requirements.txt` и затем `python run.py`.

## Запуск

После установки: `chatai` (веб) или `chatai --cli` (консоль).
Без установки пакета: `python run.py` или `python run.py --cli`.

В CLI доступны команды `/exit`, `/clear`, `/files`, `/think`.

## Настройка

Все параметры задаются переменными окружения (см. `.env.example`). Если переменная
не задана, используется значение по умолчанию из `aihuina/config.py`.

| Переменная | По умолчанию | Описание |
|---|---|---|
| `AGENT_PROVIDER` | `lmstudio` | Провайдер: `lmstudio`, `ollama`, `openai`, `xai`, `custom` |
| `AGENT_API_URL` | зависит от провайдера | URL endpoint'а chat/completions |
| `AGENT_MODEL` | зависит от провайдера | Имя модели |
| `AGENT_HOST` / `AGENT_PORT` | `127.0.0.1` / `8080` | Адрес веб-сервера |
| `AGENT_DATA` | `./agent_data` | Папка для чатов и настроек |
| `AGENT_ACTIVE_WORKSPACE` | `<AGENT_DATA>/Workspace` | Активное рабочее пространство |
| `AGENT_CMD_TIMEOUT` | `30` | Таймаут команды оболочки, сек |
| `AGENT_MAX_OUTPUT` | `8000` | Максимум символов вывода команды |
| `AGENT_MODEL_TIMEOUT` | `600` | Таймаут ответа модели, сек |
| `AGENT_MAX_ITERS` | `15` | Максимум шагов агента за один запрос |
| `AGENT_TEMP` | `0.2` | Температура генерации |
| `AGENT_MAX_CTX` | `48000` | Лимит символов контекста |
| `AGENT_CTX_SIZE` | `8192` | Размер контекста модели (если не удалось определить) |
| `AGENT_MAX_UPLOAD` | `200 МБ` | Максимальный размер загружаемого файла, байт |
| `AGENT_LMSTUDIO` | — | `1`, чтобы считать сервер LM Studio даже на нестандартном порту |
| `OPENAI_API_KEY`, `XAI_API_KEY`, `OLLAMA_API_KEY`, `LM_API_TOKEN`, `AGENT_API_KEY` | — | API-ключи провайдеров |

Ключ и URL, сохранённые через интерфейс, имеют приоритет над переменными окружения.

Примеры:

```bash
# OpenAI
AGENT_PROVIDER=openai OPENAI_API_KEY=sk-... python run.py

# Ollama на другом порту
AGENT_API_URL=http://127.0.0.1:11434/v1/chat/completions AGENT_MODEL=llama3.2 python run.py
```

## Тесты

```bash
python -m unittest discover -s tests -v
```

## Безопасность

Агент может выполнять команды оболочки и менять файлы в рабочей папке. Запускайте
его только на доверенной машине, не открывайте веб-интерфейс наружу без защиты и
следите за тем, в какую папку он работает. Простая блокировка опасных команд
задаётся списком `BLOCKED_PATTERNS` в `aihuina/config.py`; это не полноценная
песочница.

## Данные

Все чаты, настройки и файлы сохраняются в `AGENT_DATA` (по умолчанию `./agent_data`).
Эта папка не включается в репозиторий (см. `.gitignore`).


## Tools and skills

The agent reads its tool catalog from `aihuina/tools.txt` and loads Markdown skill guides from `aihuina/skills/` into the system prompt. The included `video_creation.md` skill describes an HTML scene + Python renderer workflow; actual video export depends on installed Playwright/Chromium and an encoder such as FFmpeg.

Every JSON tool call should include a short `description` field, which is surfaced in the activity feed. `run_python` executes a workspace-local Python script. `browser` provides optional Playwright-based navigation and DOM interaction; install Playwright and its Chromium browser to enable it. Screenshot-for-model-inspection is intentionally denied unless image-input support and the speed threshold can be reliably verified by the runtime.
